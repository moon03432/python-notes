class Foo:
    def hello(self):
        print("hello")

def main():
    foo = Foo()
    foo.hello()

if __name__ == '__main__':
    main()