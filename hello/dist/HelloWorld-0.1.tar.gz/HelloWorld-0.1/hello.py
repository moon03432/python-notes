#!/usr/local/bin/python3

print("Hello", "World", r"\n")
print("Hello", "World", "\n")